from .constantes import VERMELHO,AZUL,TAMANHO_QUADRADO,CINZA,COROA
import pygame

class Peca:
    espacamento = 15 
    borda_lina = 2 
    
    def __init__(self,linha,coluna,cor):
        self.linha = linha
        self.coluna = coluna
        self.cor= cor
        self.rainha = False        
        self.x = 0
        self.y = 0
        self.calc_posicao()
        
    def calc_posicao(self):
        self.x = TAMANHO_QUADRADO * self.coluna + TAMANHO_QUADRADO//2
        self.y = TAMANHO_QUADRADO * self.linha + TAMANHO_QUADRADO//2 
    
    def tornar_rainha(self):
        self.rainha = True
    
    def desenhar(self,janela):
        raio = TAMANHO_QUADRADO//2 - self.espacamento 
        pygame.draw.circle(janela,CINZA,(self.x,self.y),raio + self.borda_lina)
        pygame.draw.circle(janela,self.cor,(self.x,self.y),raio)
        if self.rainha:
            janela.blit(COROA,(self.x - COROA.get_width()//2,self.y - COROA.get_height()//2))
        
    def mover(self,linha,coluna):
        self.linha = linha
        self.coluna= coluna
        self.calc_posicao()
        
    def __repr__(self):
        return str(self.cor)