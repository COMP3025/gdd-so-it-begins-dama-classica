import pygame

COMPRIMENTO, LARGURA = 600, 600
LINHAS, COLUNAS = 8, 8
TAMANHO_QUADRADO = COMPRIMENTO//COLUNAS

VERMELHO = (255,0,0,)
AZUL = (0,0,255)
BRANCO = (255,255,255)
PRETO = (0,0,0)
CINZA = (128,128,128)

COROA = pygame.transform.scale(pygame.image.load("damas/assets/crown.png"),(35,15))