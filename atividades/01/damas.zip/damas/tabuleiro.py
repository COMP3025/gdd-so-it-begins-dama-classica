import pygame
from .constantes import COLUNAS, LINHAS ,TAMANHO_QUADRADO ,PRETO, AZUL, VERMELHO, BRANCO
from .pecas import  Peca

class Tabuleiro:
    def __init__(self):
        self.tabuleiro = []        
        self.azul_restantes = self.vermelha_restantes = 12
        self.rainhas_azul = self.rainhas_branca = 0 
        self.criar_tabuleiro()
        
    def desenhar_quadrados(self,janela):
        janela.fill(PRETO)
        for linha in range(LINHAS):
            for coluna in range(linha % 2, LINHAS, 2):
                pygame.draw.rect(janela,BRANCO,(linha * TAMANHO_QUADRADO, coluna * TAMANHO_QUADRADO, TAMANHO_QUADRADO, TAMANHO_QUADRADO))
                
    def criar_tabuleiro(self):
        for linha in range(LINHAS):
            self.tabuleiro.append([])            
            for coluna in range(COLUNAS):
                if coluna % 2 == ((linha + 1) % 2):
                    if linha < 3:
                        self.tabuleiro[linha].append(Peca(linha,coluna,AZUL))
                    elif linha > 4:
                        self.tabuleiro[linha].append(Peca(linha,coluna,VERMELHO))
                    else:
                        self.tabuleiro[linha].append(0)
                else:
                    self.tabuleiro[linha].append(0)
    def remover(self,pecas):
        for peca in pecas:
            self.tabuleiro[peca.linha][peca.coluna] = 0
            if peca != 0:
                if peca.cor == VERMELHO:
                    
                    self.vermelha_restantes -= 1
                else:
                    self.azul_restantes -= 1
       
    def vencendor(self):
        if self.vermelha_restantes <= 0:
            return AZUL
        elif self.azul_restantes <= 0:
            return VERMELHO
    
        return None
            
    def mover(self,peca,linha,coluna):
        self.tabuleiro[peca.linha][peca.coluna], self.tabuleiro[linha][coluna] = self.tabuleiro[linha][coluna],self.tabuleiro[peca.linha][peca.coluna]
        peca.mover(linha,coluna)
        
        if linha == LINHAS -1 or linha == 0:
            peca.tornar_rainha()
            if peca.cor == AZUL:
                self.azul_restantes += 1
            else:
                self.vermelha_restantes += 1
    
    def obter_peca(self,linha,coluna):
        return self.tabuleiro[linha][coluna]
        
    def desenhar(self,janela):
        self.desenhar_quadrados(janela)
        for linha in range(LINHAS):
            for coluna in range(COLUNAS):
                peca = self.tabuleiro[linha][coluna]
                if peca != 0:
                    peca.desenhar(janela)
                    
    def obter_movimentos_validos(self,peca):
        movimentos = {}
        esquerda = peca.coluna - 1
        direita = peca.coluna + 1
        linha = peca.linha
        if peca.cor == VERMELHO or peca.rainha:
            movimentos.update(self._atravessar_esquerda(linha -1 ,max(linha-3,-1),-1,peca.cor,esquerda))
            movimentos.update(self._atravessar_direita(linha -1 ,max(linha-3,-1),-1,peca.cor,direita))
        if peca.cor == AZUL or peca.rainha:
            movimentos.update(self._atravessar_esquerda(linha +1 ,min(linha+3,LINHAS),1,peca.cor,esquerda))
            movimentos.update(self._atravessar_direita(linha +1 ,min(linha+3,LINHAS),1,peca.cor,direita))
        
        return movimentos
     
    def _atravessar_esquerda(self,inicio,parada,etapa,cor,esquerda,pulou=[]):
        movimentos = {}
        ultimo = []
        for r in range(inicio,parada,etapa):
            if esquerda < 0:
                break
            atual = self.tabuleiro[r][esquerda]
            if atual == 0:
                if pulou and not ultimo:
                    break
                elif pulou:
                    movimentos[(r,esquerda)] = ultimo + pulou
                else:
                    movimentos[(r,esquerda)] = ultimo
                
                if ultimo:
                    if etapa == -1:
                        linha = max(r-3,0)
                    else:
                        linha = min(r+3,LINHAS)
                    movimentos.update(self._atravessar_esquerda(r+etapa,linha,etapa,cor,esquerda -1,pulou=ultimo))
                    movimentos.update(self._atravessar_direita(r+etapa,linha,etapa,cor,esquerda + 1,pulou=ultimo))
                break
            elif atual.cor == cor:
                break
            else:
                ultimo = [atual]
                
            esquerda -= 1
        return movimentos
    
    def _atravessar_direita(self,inicio,parada,etapa,cor,direita,pulou=[]):
        movimentos = {}
        ultimo = []
        for r in range(inicio,parada,etapa):
            if direita >= COLUNAS:
                break
            atual = self.tabuleiro[r][direita]
            if atual == 0:
                if pulou and not ultimo:
                    break
                elif pulou:
                    movimentos[(r,direita)] = ultimo + pulou
                else:
                    movimentos[(r,direita)] = ultimo
                
                if ultimo:
                    if etapa == -1:
                        linha = max(r-3,0)
                    else:
                        linha = min(r+3,LINHAS)
                    movimentos.update(self._atravessar_esquerda(r+etapa,linha,etapa,cor,direita -1,pulou=ultimo))
                    movimentos.update(self._atravessar_direita(r+etapa,linha,etapa,cor,direita + 1,pulou=ultimo))
                break
            elif atual.cor == cor:
                break
            else:
                ultimo = [atual]
                
            direita += 1
        return movimentos